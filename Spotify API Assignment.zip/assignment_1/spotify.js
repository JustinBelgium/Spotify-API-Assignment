const https = require('https'); // Spotify requires https
const querystring = require('querystring'); 
const readline = require('readline'); // for user input

// API account credentials
const clientID = '1ef922544bdf4d96a697b881c998b078';
const clientSecret = 'a949687d674847ebab2c6c81cf2dc173';

// This function will get an access token needed to make an api call.
function getAccessToken(callback) {
    const authOptions = {
        hostname: 'accounts.spotify.com',
        path: '/api/token',
        method: 'POST',
        headers: {
            'Authorization': 'Basic ' + Buffer.from(clientID + ':' + clientSecret).toString('base64'),
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    };

    const req = https.request(authOptions, (res) => {
        let data = '';

        res.on('data', (chunk) => {
            data = data.concat(chunk);
        });

        res.on('end', () => {
            try {
                const json = JSON.parse(data);
                callback(json.access_token);
            } catch (error) {
                console.error('Error parsing JSON:', error);
            }
        });
    });

    req.on('error', (error) => {
        console.error('Request error:', error);
    });

    req.write(querystring.stringify({ grant_type: 'client_credentials' }));
    req.end();
}

// This function searches for the song name
function searchSong(accessToken, songName, callback) {
    const query = querystring.stringify({ q: songName, type: 'track', limit: 1 });
    const options = {
        hostname: 'api.spotify.com',
        path: `/v1/search?${query}`,
        method: 'GET',
        headers: {
            'Authorization': 'Bearer ' + accessToken
        }
    };

    const req = https.request(options, (res) => {
        let data = '';

        res.on('data', (chunk) => {
            data = data.concat(chunk);
        });

        res.on('end', () => {
            try {
                const json = JSON.parse(data);
                const track = json.tracks.items[0];
                if (track) {
                    callback(track);
                } else {
                    console.log('Song Not Found.');
                    showMenu();
                }
            } catch (error) {
                console.error('Error parsing JSON:', error);
                showMenu();
            }
        });
    });

    req.on('error', (error) => {
        console.error('Request error:', error);
        showMenu();
    });

    req.end();
}

// This function retrieves and outputs the details of a song
function getSongDetails(track) {
    const songDetails = {
        artist: track.artists.map(artist => artist.name),
        song: track.name,
        preview_url: track.preview_url,
        album: track.album.name
    };

    console.log('\nArtist Name: ' + songDetails.artist.toString() +
        '\nSong Name: ' + songDetails.song.toString() +
        '\nPreview URL: ' + (songDetails.preview_url ? songDetails.preview_url.toString() : 'No Preview URL Available.'));
}

// Create a readline interface
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Function to show the menu and handle user input
function showMenu() {
    console.log('\nMenu:\n1. Spotify Song Search\n2. Exit');
    rl.question('Choose an option: ', (option) => {
        switch (option) {
            case '1':
                rl.question('Enter Song Name: ', (songName) => {
                    getAccessToken((accessToken) => {
                        searchSong(accessToken, songName, (track) => {
                            getSongDetails(track);
                            showMenu(); // Show the menu again after displaying song details
                        });
                    });
                });
                break;
            case '2':
                console.log('Exiting...');
                rl.close();
                break;
            default:
                console.log('Invalid option. Please choose again.');
                showMenu();
                break;
        }
    });
}

// Show the menu initially
showMenu();
